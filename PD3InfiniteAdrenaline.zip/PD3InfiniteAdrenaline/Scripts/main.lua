-- PAYDAY 3 - Slow Decay Adrenaline Only (Damage Drain Enabled)
-- UE4SS Lua mod

local TAG = "[SlowAdrenaline]"

local ABILITY_CLASS_SHORT = "SBZPlayerAbilitySystemComponent"
local ABILITY_CLASS_PATH = "/Script/Starbreeze.SBZPlayerAbilitySystemComponent"

-- Настрой под желаемую скорость естественного распада (в секундах)
local TARGET_DECAY_INTERVAL = 10.0

local POLL_MS = 500

local ability_cdo_done = false
local seen_ability = {}

local function log(msg)
    print(TAG .. " " .. tostring(msg))
end

local function valid(obj)
    if obj == nil then
        return false
    end

    local ok, result = pcall(function()
        return obj:IsValid()
    end)

    return ok and result == true
end

local function unwrap(param)
    if param == nil then
        return nil
    end

    local ok, value = pcall(function()
        return param:get()
    end)

    if ok then
        return value
    end

    return param
end

local function fullname(obj)
    obj = unwrap(obj)

    if not valid(obj) then
        return "<invalid>"
    end

    local ok, result = pcall(function()
        return obj:GetFullName()
    end)

    if ok and result then
        return tostring(result)
    end

    return "<name-error>"
end

-- ============================================================
-- LAYER 1 - Slow natural degradation tick
-- ============================================================

local function patch_decay_component(obj, label)
    if not valid(obj) then
        return false
    end

    local before = nil
    local ok_read = pcall(function()
        before = obj.OverHealDegradationTickInterval
    end)

    if not ok_read or type(before) ~= "number" then
        return false
    end

    if math.abs(before - TARGET_DECAY_INTERVAL) < 0.001 then
        return true
    end

    local ok_write, err = pcall(function()
        obj.OverHealDegradationTickInterval = TARGET_DECAY_INTERVAL
    end)

    if not ok_write then
        log(label .. " | decay WRITE FAILED: " .. tostring(err))
        return false
    end

    local after = nil
    pcall(function()
        after = obj.OverHealDegradationTickInterval
    end)

    if type(after) == "number" and math.abs(after - TARGET_DECAY_INTERVAL) < 0.001 then
        log(string.format(
            "%s | PATCHED natural decay interval: %.2f -> %.2f | %s",
            label,
            before,
            after,
            fullname(obj)
        ))
        return true
    end

    return false
end

local function patch_ability_cdo()
    if ability_cdo_done then
        return
    end

    local cls = nil
    pcall(function()
        cls = StaticFindObject(ABILITY_CLASS_PATH)
    end)

    if not valid(cls) then
        return
    end

    local cdo = nil
    pcall(function()
        cdo = cls:GetCDO()
    end)

    if valid(cdo) and patch_decay_component(cdo, "ABILITY CDO") then
        ability_cdo_done = true
        log("Ability CDO ready.")
    end
end

local function patch_live_ability()
    local obj = nil
    pcall(function()
        obj = FindFirstOf(ABILITY_CLASS_SHORT)
    end)

    if not valid(obj) then
        return
    end

    local name = fullname(obj)
    if patch_decay_component(obj, "ABILITY LIVE") and not seen_ability[name] then
        seen_ability[name] = true
        log("Live ability component ready | " .. name)
    end
end

-- ============================================================
-- Main
-- ============================================================

local function tick()
    patch_ability_cdo()
    patch_live_ability()
end

log("Slow Decay Adrenaline loaded (damage drain normal).")

LoopAsync(POLL_MS, function()
    ExecuteInGameThread(function()
        local ok, err = pcall(tick)
        if not ok then
            log("TICK ERROR: " .. tostring(err))
        end
    end)

    return false
end)