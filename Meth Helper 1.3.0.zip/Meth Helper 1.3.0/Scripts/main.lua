-- Meth Helper (PAYDAY 3, UE4SS)

local VERSION = "1.3.0"
local DEFAULT_LANG = "en"  

local RESEND_SECS = 40
local CLIENT_WAIT_MS = 1500

local function now() return os.clock() end

local function try(f, ...)
    local ok, r = pcall(f, ...)
    if ok then return r end
    return nil
end

local function isReal(o)
    if not o or not o:IsValid() then return false end
    local n = try(function() return o:GetFName():ToString() end) or ""
    return not n:find("^Default__")
end

local function addrOf(o)
    return try(function() return o:GetAddress() end)
end

---------------------------------------------------------------------
-- Texts
---------------------------------------------------------------------
local L = {
    en = {
        names = { "Соляная кислота", "Каустическая сода", "Хлористый водород" },
        put = "Залейте: %s",
        added = "Ингредиент добавлен",
        pure = "Мет чистый, забирайте!",
        wrong_you = "Вы залили не тот ингредиент!",
        wrong_player = "Игрок %s залил не тот ингредиент.",
        wrong_someone = "Один из игроков залил не тот ингредиент.",
        lang_set = "Язык изменён на Русский",
        on = "Мод включён",
        off = "Мод выключен",
        all_on = "Рассылка всем: ВКЛ (только хост)",
        all_off = "Рассылка всем: ВЫКЛ (только вы)",
        shame_1 = "Ошибка всем: ВКЛ (только хост)",
        shame_0 = "Ошибка всем: ВЫКЛ (только вы)",
        scroll_on = "Фикс прокрутки чата: ВКЛ",
        scroll_off = "Фикс прокрутки чата: ВЫКЛ",
        langname = "Русский", v_on = "ВКЛ", v_off = "ВЫКЛ",
        st_info = "v%s [%s] | Мод: %s | Всем: %s | Ошибка: %s | Скролл: %s",
        help = "Команды: /meth [on|off] [ru|en|pt|es] [all] [shame] [scroll]",
    },
    pt = {
        names = { "Ácido Muriático", "Soda Cáustica", "Cloreto de Hidrogênio" },
        put = "Coloque %s",
        added = "Ingrediente adicionado",
        pure = "Meth pura, pegue agora!",
        wrong_you = "Você colocou o ingrediente errado!",
        wrong_player = "O jogador %s colocou o ingrediente errado.",
        wrong_someone = "Um jogador colocou o ingrediente errado.",
        lang_set = "Idioma alterado para Português (Brasil)",
        on = "Mod Ativado",
        off = "Mod Desativado",
        all_on = "Avisos para todos: LIGADO (só host)",
        all_off = "Avisos para todos: DESLIGADO (só você)",
        shame_1 = "Erro para todos: LIGADO (só host)",
        shame_0 = "Erro para todos: DESLIGADO (só você)",
        scroll_on = "Correção de scroll: LIGADA",
        scroll_off = "Correção de scroll: DESLIGADA",
        langname = "Português", v_on = "LIGADO", v_off = "DESLIGADO",
        st_info = "v%s [%s] | Mod: %s | Todos: %s | Erro: %s | Scroll: %s",
        help = "Comandos: /meth [on|off] [en|pt|es] [all] [shame] [scroll]",
    },
    es = {
        names = { "Ácido Muriático", "Sosa Cáustica", "Cloruro de Hidrógeno" },
        put = "Coloca %s",
        added = "Ingrediente añadido",
        pure = "¡Metanfetamina pura, agárrala ya!",
        wrong_you = "¡Pusiste el ingrediente equivocado!",
        wrong_player = "El jugador %s puso el ingrediente equivocado.",
        wrong_someone = "Un jugador puso el ingrediente equivocado.",
        lang_set = "Idioma cambiado a Español",
        on = "Mod Activado",
        off = "Mod Desactivado",
        all_on = "Avisos para todos: ACTIVADO (solo host)",
        all_off = "Avisos para todos: DESACTIVADO (solo tú)",
        shame_1 = "Error para todos: ACTIVADO (solo host)",
        shame_0 = "Error para todos: DESACTIVADO (solo tú)",
        scroll_on = "Corrección de scroll: ACTIVADA",
        scroll_off = "Corrección de scroll: DESACTIVADA",
        langname = "Español", v_on = "ACTIVADO", v_off = "DESACTIVADO",
        st_info = "v%s [%s] | Mod: %s | Todos: %s | Error: %s | Scroll: %s",
        help = "Comandos: /meth [on|off] [en|pt|es] [all] [shame] [scroll]",
    },
}

---------------------------------------------------------------------
-- Settings (saved next to the mod)
---------------------------------------------------------------------
local CONFIG_FILE = (function()
    local src = debug.getinfo(1, "S").source or ""
    local dir = src:match("^@?(.*)[/\\]Scripts[/\\][^/\\]*$")
    return dir and (dir .. "/config.txt") or nil
end)()

local state = { lang = DEFAULT_LANG, enabled = true, broadcast = true, shame = false, scrollfix = true }

local function loadConfig()
    if not CONFIG_FILE then return end
    pcall(function()
        local f = io.open(CONFIG_FILE, "r")
        if not f then return end
        for line in f:lines() do
            local k, v = line:match("^([%w_]+)%s*=%s*(%S*)")
            if k == "lang" and L[v] then state.lang = v end
            if k == "enabled" then state.enabled = (v ~= "0") end
            if k == "broadcast" then state.broadcast = (v ~= "0") end
            if k == "shame" then state.shame = (v == "1") end
            if k == "scrollfix" then state.scrollfix = (v ~= "0") end
        end
        f:close()
    end)
end

local function saveConfig()
    if not CONFIG_FILE then return end
    pcall(function()
        local f = io.open(CONFIG_FILE, "w")
        if not f then return end
        f:write("lang=" .. state.lang .. "\n")
        f:write("enabled=" .. (state.enabled and "1" or "0") .. "\n")
        f:write("broadcast=" .. (state.broadcast and "1" or "0") .. "\n")
        f:write("shame=" .. (state.shame and "1" or "0") .. "\n")
        f:write("scrollfix=" .. (state.scrollfix and "1" or "0") .. "\n")
        f:close()
    end)
end

loadConfig()

---------------------------------------------------------------------
-- Colors (styles from the game's chat style table)
---------------------------------------------------------------------
local STYLE = { brand = "Blue", ingredient = "Skills1", ok = "Good", bad = "Bad", name = "PlayerName", hl = "Skill" }

local function styled(text, key)
    return "<" .. STYLE[key] .. ">" .. text .. "</>"
end

---------------------------------------------------------------------
-- Local player, host/client, game clock
---------------------------------------------------------------------
local cachedPS = nil
local lastStation = nil     -- most recent cooking station seen
local lastLevel = nil       -- level script object seen by a hook
local cachedProxy = nil     -- SBZVotingReplicatedProxy cached

local function localPlayerState()
    if cachedPS and cachedPS:IsValid() then return cachedPS end
    cachedPS = nil
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if isReal(pc) and try(function() return pc:IsLocalController() end) == true then
            local ps = try(function() return pc.PlayerState end)
            if ps and ps:IsValid() then
                cachedPS = ps
                return ps
            end
        end
    end
    return nil
end

local function validContext()
    if isReal(lastStation) then return lastStation end
    if isReal(lastLevel) then return lastLevel end
    local lp = localPlayerState()
    if isReal(lp) then return lp end
    return nil
end

local ksl = nil
local isHostCached = nil
local function isHost(ctx)
    if isHostCached ~= nil then return isHostCached end
    ctx = ctx or validContext()
    if not ctx or not isReal(ctx) then return nil end
    local r
    pcall(function()
        ksl = ksl or StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if ksl and ksl:IsValid() then
            r = ksl:IsServer(ctx)
        end
    end)
    if r ~= nil then isHostCached = (r == true) end
    return isHostCached
end

---------------------------------------------------------------------
-- Chat screen & Safe Chat History Preservation
---------------------------------------------------------------------
local chatWidget, widgetPrio = nil, 0
local callingWidget = false   -- true while this mod itself writes to the chat
local pending = {}

local function currentWidget()
    if chatWidget and chatWidget:IsValid() then return chatWidget end
    chatWidget, widgetPrio = nil, 0
    return nil
end

local gameplayStatics = nil
local gtWorks = nil
local lastGT = 0
local function clock()
    if gtWorks ~= false then
        local ctx = localPlayerState() or currentWidget()
        local t
        if ctx and isReal(ctx) then
            pcall(function()
                gameplayStatics = gameplayStatics or StaticFindObject("/Script/Engine.Default__GameplayStatics")
                if gameplayStatics and gameplayStatics:IsValid() then
                    t = gameplayStatics:GetTimeSeconds(ctx)
                end
            end)
            t = tonumber(t)
            if t then
                gtWorks, lastGT = true, t
                return t
            end
            if gtWorks == nil then gtWorks = false end
        end
        if gtWorks ~= false then return lastGT end
    end
    return os.clock()
end

local function later(ms, fn)
    if ExecuteWithDelay then
        local ok = pcall(ExecuteWithDelay, ms, function() ExecuteInGameThread(fn) end)
        if ok then return end
    end
    ExecuteInGameThread(fn)
end

local function showLine(widget, text)
    if not widget then return end
    ExecuteInGameThread(function()
        if not widget:IsValid() then return end
        callingWidget = true
        pcall(function() widget:SystemMessageReceived({ Message = text }) end)
        callingWidget = false
    end)
end

local function flushPending()
    local w = currentWidget()
    if not w or #pending == 0 then return end
    local list = pending
    pending = {}
    for _, p in ipairs(list) do
        if now() - p.at < 90 then showLine(w, p.text) end
    end
end

local registerBurst
local function captureWidget(o, prio)
    if callingWidget then return end
    if not o or not isReal(o) then return end
    local cur = currentWidget()
    if cur and prio < widgetPrio then return end
    local changed = (not cur) or addrOf(cur) ~= addrOf(o)
    chatWidget, widgetPrio = o, prio
    if changed then
        flushPending()
        if registerBurst then registerBurst() end
    end
end

local function showLocal(text)
    local w = currentWidget()
    if w then
        showLine(w, text)
    else
        pending[#pending + 1] = { text = text, at = now() }
        if #pending > 5 then table.remove(pending, 1) end
    end
end

-- Chat Scroll Fix:
-- Detects if player has scrolled up to inspect chat history.
-- If user is reading history (difference > 50px), NEVER force scroll down!
local function isScrolledUp(widget)
    if not widget or not widget:IsValid() then return false end
    local sb = try(function() return widget.ScrollBox_Text end)
    if not sb or not sb:IsValid() then return false end
    local off = tonumber(try(function() return sb:GetScrollOffset() end))
    local en = tonumber(try(function() return sb:GetScrollOffsetOfEnd() end))
    if not (off and en) then return false end
    return (en - off) > 50
end

local function scrollToEnd(widget, force)
    if not state.scrollfix then return end
    if not widget or not widget:IsValid() then return end
    local sb = try(function() return widget.ScrollBox_Text end)
    if not sb or not sb:IsValid() then return end
    if not force and isScrolledUp(widget) then return end
    pcall(function() sb:ScrollToEnd() end)
end

local lastScrollAt, lastScrollAddr = -99, nil
local function onScrollTrigger(self)
    if not state.scrollfix then return end
    local w = try(function() return self:get() end)
    if not w or not w:IsValid() then return end
    local t, a = now(), addrOf(w)
    if a == lastScrollAddr and t - lastScrollAt < 0.05 then return end
    lastScrollAt, lastScrollAddr = t, a

    -- If player scrolled up, do NOT yank them down!
    if isScrolledUp(w) then return end

    -- Normal live view: gentle updates for Slate layout
    later(50, function()
        if state.scrollfix and not isScrolledUp(w) then scrollToEnd(w) end
    end)
    later(150, function()
        if state.scrollfix and not isScrolledUp(w) then scrollToEnd(w) end
    end)
end

-- Detects if host also has Meth Helper running and broadcasting
local hostHasMod = false
local hostNoticeAt = -99
local function onVotingMessage(self, p)
    local msg = try(function()
        local m = p:get().Message
        return type(m) == "string" and m or m:ToString()
    end)
    if type(msg) == "string" and msg:find("[Meth Helper]", 1, true) then
        hostNoticeAt = now()
        hostHasMod = true
    end
end

---------------------------------------------------------------------
-- Notices & Announcements
---------------------------------------------------------------------
local lastMsg, lastAt = nil, -99

local function sendBroadcast(full)
    if not cachedProxy or not cachedProxy:IsValid() then
        cachedProxy = nil
        for _, o in ipairs(FindAllOf("SBZVotingReplicatedProxy") or {}) do
            if isReal(o) then cachedProxy = o; break end
        end
    end
    if not cachedProxy then return false end
    local ok = pcall(function() cachedProxy:MulticastReceiveChatMessage(full) end)
    return ok
end

local function announce(text, fromEvent, hostOnly)
    if text == lastMsg and now() - lastAt < 3.0 then return end
    lastMsg, lastAt = text, now()
    local full = styled("[Meth Helper]", "brand") .. " " .. text
    local evAt = now()
    ExecuteInGameThread(function()
        local host = isHost(validContext())
        if host == true and state.broadcast and not hostOnly and sendBroadcast(full) then
            return
        end
        -- Client: only wait 150ms if we confirmed the host has the mod; otherwise show instantly!
        if host == false and fromEvent and hostHasMod then
            later(150, function()
                if hostNoticeAt >= evAt - 1.0 then return end
                showLocal(full)
            end)
            return
        end
        showLocal(full)
    end)
end

local lastReqIdx = nil
local pendingReq = nil      -- { idx = N, lastSent = game seconds }
local sabotaged = false
local curState = nil
local resendLoopOn = false
local ackInteractor = nil

local function requestText(idx)
    local t = L[state.lang]
    local name = idx and t.names[idx]
    if not name then return nil end
    return string.format(t.put, styled(name, "ingredient"))
end

local function resendTick()
    local req = pendingReq
    if not req then return end
    if not state.enabled then pendingReq = nil; return end
    local c = clock()
    if sabotaged then req.lastSent = c; return end
    if c - req.lastSent >= RESEND_SECS then
        req.lastSent = c
        local text = requestText(req.idx)
        if text then
            lastMsg = nil
            announce(text)
        end
    end
end

local function startResendLoop()
    if resendLoopOn then return end
    resendLoopOn = true
    LoopAsync(1000, function()
        if not pendingReq or not state.enabled then
            resendLoopOn = false
            return true
        end
        ExecuteInGameThread(resendTick)
        return false
    end)
end

local function newRequest(idx)
    if idx ~= nil and idx == lastReqIdx then return end
    lastReqIdx = idx
    local text = requestText(idx)
    if not text then return end
    pendingReq = { idx = idx, lastSent = clock() }
    startResendLoop()
    if not sabotaged then announce(text) end
end

---------------------------------------------------------------------
-- Who put the wrong ingredient
---------------------------------------------------------------------
local function playerStateOf(actor)
    if not actor or not actor:IsValid() then return nil end
    local ps = try(function() return actor.PlayerState end)
    if ps and ps:IsValid() then return ps end
    return nil
end

local function nameOf(ps)
    local n = try(function() return ps:GetPlayerName():ToString() end)
    if type(n) ~= "string" or n == "" then return nil end
    return (n:gsub("[<>]", ""))
end

local function findCulprit()
    local a = ackInteractor
    if a and now() - a.at < 3 and a.comp and a.comp:IsValid() then
        local ps = playerStateOf(try(function() return a.comp:GetOwner() end))
        if ps or a.localCtl == true then return ps, a.localCtl == true end
    end
    local st = lastStation
    if st and st:IsValid() then
        local ps = playerStateOf(try(function() return st.LastInteractor end))
        if ps then return ps, nil end
        local loc = try(function() return st:K2_GetActorLocation() end)
        if loc then
            local best, bestD
            for _, ch in ipairs(FindAllOf("SBZPlayerCharacter") or {}) do
                if isReal(ch) then
                    local p = try(function() return ch:K2_GetActorLocation() end)
                    local cps = p and playerStateOf(ch)
                    if cps then
                        local d = (p.X - loc.X) ^ 2 + (p.Y - loc.Y) ^ 2 + (p.Z - loc.Z) ^ 2
                        if not bestD or d < bestD then best, bestD = cps, d end
                    end
                end
            end
            if best then return best, nil end
        end
    end
    return nil, nil
end

local function wrongPlayerText(t, name)
    local pre, post = t.wrong_player:match("^(.-)%%s(.*)$")
    local parts = {}
    if pre and pre ~= "" then parts[#parts + 1] = styled(pre, "bad") end
    parts[#parts + 1] = styled(name, "name")
    if post and post ~= "" then parts[#parts + 1] = styled(post, "bad") end
    return table.concat(parts)
end

local function announceWrong()
    if not state.enabled then return end
    local t = L[state.lang]
    local ps, isLocal = findCulprit()
    if isLocal == nil and ps then
        local lp = localPlayerState()
        local a1, a2 = lp and addrOf(lp), addrOf(ps)
        if a1 and a2 and a1 == a2 then isLocal = true end
    end
    local text
    if isLocal then
        text = styled(t.wrong_you, "bad")
    else
        local name = ps and nameOf(ps)
        text = name and wrongPlayerText(t, name) or styled(t.wrong_someone, "bad")
    end
    announce(text, true, not state.shame)
end

---------------------------------------------------------------------
-- Kitchen events
---------------------------------------------------------------------
local function levelContext(self)
    local obj = try(function() return self:get() end)
    if not obj or not obj:IsValid() then return nil end
    lastLevel = obj
    if not state.enabled then return nil end
    return obj
end

local function onIngredient(self, p)
    if not levelContext(self) then return end
    newRequest(tonumber(try(function() return p:get() end)))
end

local function onAdded(self, p)
    lastReqIdx = nil
    pendingReq = nil
    if not levelContext(self) then return end
    local v = try(function() return p:get() end)
    if v == true then
        announce(styled(L[state.lang].added, "ok"), true)
    elseif v == false then
        announceWrong()
    end
end

-- states: 0 Inactive, 1 WaitingForIngredients, 2 Cooking, 3 UnderCooked,
-- 4 Cooked (pure), 5 OverCooked, 6 Sabotaged, 7 Destroyed
local function applyState(new, old, station)
    if new == nil or new == curState then return end
    local prev = old or curState
    curState = new
    if station and isReal(station) then lastStation = station end

    if new == 0 then lastReqIdx = nil end

    if new == 6 then
        sabotaged = true
    elseif sabotaged then
        sabotaged = false
        if pendingReq then pendingReq.lastSent = clock() end
    end

    if new ~= 1 and new ~= 6 then pendingReq = nil end

    if not state.enabled then return end

    if new == 4 and prev ~= 4 then
        announce(styled(L[state.lang].pure, "ok"), true)
    end

    -- Client only: host reports wrong ingredient from level script
    if new == 7 and prev == 1 and station and isHost(station) == false then
        announceWrong()
    end
end

local function onState(self, oldP, newP)
    if not levelContext(self) then return end
    applyState(tonumber(try(function() return newP:get() end)),
               tonumber(try(function() return oldP:get() end)), nil)
end

local function onMulticastSetState(self, p)
    if not state.enabled then return end
    local station = try(function() return self:get() end)
    applyState(tonumber(try(function() return p:get() end)), nil, station)
end

local function onRepState(self)
    if not state.enabled then return end
    local o = try(function() return self:get() end)
    if not o or not o:IsValid() then return end
    applyState(tonumber(try(function() return o.CurrentState end)), nil, o)
end

local function onSabotage(self, p)
    if not state.enabled then return end
    local v = try(function() return p:get() end)
    if v == true then
        sabotaged = true
    elseif v == false and sabotaged then
        sabotaged = false
        if pendingReq then pendingReq.lastSent = clock() end
    end
end

local function onAck(self, comp, interactor, localCtl)
    if not state.enabled then return end
    local station = try(function() return self:get() end)
    if station and station:IsValid() then lastStation = station end
    ackInteractor = {
        comp = try(function() return interactor:get() end),
        localCtl = try(function() return localCtl:get() end),
        at = now(),
    }
    pendingReq = nil
    lastReqIdx = nil
end

-- Client only: ingredient added notification (fast 150ms verification)
local lastAddedAt = -99
local function onBPIngredientAdded(self)
    local station = try(function() return self:get() end)
    if now() - lastAddedAt < 0.3 then return end
    lastAddedAt = now()
    if station and station:IsValid() then lastStation = station end
    if not state.enabled then return end
    pendingReq, lastReqIdx = nil, nil
    bluff = nil

    local host = isHost(station or validContext())
    if host == false or isHostCached == false then
        later(150, function()
            if curState ~= 7 then
                announce(styled(L[state.lang].added, "ok"), false)
            end
        end)
    end
end

---------------------------------------------------------------------
-- Chat commands (Streamlined & Minimal)
---------------------------------------------------------------------
local function statusText()
    local t = L[state.lang]
    local function onoff(v) return styled(v and t.v_on or t.v_off, v and "ok" or "bad") end
    return {
        string.format(t.st_info, styled(VERSION, "hl"), styled(t.langname, "hl"),
            onoff(state.enabled), onoff(state.broadcast), onoff(state.shame), onoff(state.scrollfix)),
        styled(t.help, "hl")
    }
end

local function onTextCommited(self, textParam)
    local widget = try(function() return self:get() end)
    captureWidget(widget, 3)
    local v = try(function() return textParam:get() end)
    local raw = type(v) == "string" and v or try(function() return v:ToString() end)
    if type(raw) ~= "string" then return end
    local s = raw:gsub("^%s+", ""):lower()
    if s:sub(1, 5) ~= "/meth" then return end

    local arg = s:match("^/meth%s+(%S+)") or ""
    local arg2 = s:match("^/meth%s+%S+%s+(%S+)") or ""
    local t = L[state.lang]
    local reply

    if arg == "" or arg == "status" or arg == "help" then
        reply = statusText()
    elseif arg == "en" then
        state.lang = "en"; saveConfig(); reply = L.en.lang_set
    elseif arg == "pt" or arg == "ptbr" then
        state.lang = "pt"; saveConfig(); reply = L.pt.lang_set
    elseif arg == "es" or arg == "espanol" or arg == "español" then
        state.lang = "es"; saveConfig(); reply = L.es.lang_set
    elseif arg == "on" then
        state.enabled = true; saveConfig(); reply = t.on
    elseif arg == "off" then
        state.enabled = false; saveConfig(); reply = t.off
    elseif arg == "all" then
        if arg2 == "on" then state.broadcast = true
        elseif arg2 == "off" then state.broadcast = false
        else state.broadcast = not state.broadcast end
        saveConfig()
        reply = state.broadcast and t.all_on or t.all_off
    elseif arg == "shame" then
        if arg2 == "1" or arg2 == "on" then state.shame = true
        elseif arg2 == "0" or arg2 == "off" then state.shame = false
        else state.shame = not state.shame end
        saveConfig()
        reply = state.shame and t.shame_1 or t.shame_0
    elseif arg == "scroll" or arg == "scrollfix" then
        if arg2 == "on" then state.scrollfix = true
        elseif arg2 == "off" then state.scrollfix = false
        else state.scrollfix = not state.scrollfix end
        saveConfig()
        reply = state.scrollfix and t.scroll_on or t.scroll_off
    else
        reply = statusText()
    end

    pcall(function() textParam:set(FText("")) end)

    if type(reply) == "table" then
        for i, line in ipairs(reply) do
            showLine(widget, (i == 1 and (styled("[Meth Helper]", "brand") .. " ") or "") .. line)
        end
    else
        showLine(widget, styled("[Meth Helper]", "brand") .. " " .. reply)
    end
    -- Force scroll to bottom on own commands
    scrollToEnd(widget, true)
end

local function onFallback(self)
    if callingWidget then return end
    captureWidget(try(function() return self:get() end), 2)
end

---------------------------------------------------------------------
-- Narrator cues (client only)
---------------------------------------------------------------------
local CUES = {}
do
    local function put(first, last, kind, base)
        for n = first, last do
            CUES["sha_rmk02_" .. n] = { kind = kind, idx = base and (n - first + 1) or nil }
        end
    end
    put(16, 18, "sure", true)
    put(26, 28, "sure", true)
    put(19, 21, "maybe", true)
    put(23, 25, "stop")
    put(15, 15, "stop")
end

local BLUFF_GRACE_MS = 2500
local HOST_SAID_SECS = 8.0
local bluff = nil

local function cueName(obj)
    if not obj or not obj:IsValid() then return nil end
    local full = try(function() return obj:GetFullName() end)
    return full and full:match("sha_[%w_]+") or nil
end

local function tellLocally(idx)
    local body = requestText(idx)
    if not body then return end
    local line = styled("[Meth Helper]", "brand") .. " " .. body
    local heardAt = now()
    later(CLIENT_WAIT_MS, function()
        if hostNoticeAt >= heardAt - HOST_SAID_SECS then return end
        if line == lastMsg and now() - lastAt < 3.0 then return end
        lastMsg, lastAt = line, now()
        showLocal(line)
    end)
end

local function listenNarrator(self, dialogAsset)
    if not state.enabled then return end
    local name = cueName(try(function() return dialogAsset:get() end))
    if not name then return end

    local ctx = lastStation or lastLevel or localPlayerState() or currentWidget() or try(function() return self:get() end)
    if isHost(ctx) ~= false then return end

    local cue = CUES[name]
    if not cue then return end

    if cue.kind == "stop" then
        bluff = nil
    elseif cue.kind == "sure" then
        bluff = nil
        tellLocally(cue.idx)
    else
        local mine = { idx = cue.idx }
        bluff = mine
        later(BLUFF_GRACE_MS, function()
            if bluff == mine and state.enabled then
                bluff = nil
                tellLocally(mine.idx)
            end
        end)
    end
end

---------------------------------------------------------------------
-- Hooks
---------------------------------------------------------------------
local LEVEL_CLASS = "/Game/DLCs/00242-COOKIE/Maps/Sublevels/Gameplay_Cookie/G_Cookie_Scripting.G_Cookie_Scripting_C"
local LEVEL = LEVEL_CLASS .. ":"
local STATION_BP = "/Game/DLCs/00004-DLCREMA/Prototype/Maps/Villa/Blueprints/BP_MethCookingStation.BP_MethCookingStation_C"

local LABS = {
    { prefix = "BndEvt__G_Villa_Scripting_BP_MethCookingStation_2_K2Node_ActorBoundEvent_",  ing = 55, added = 37, state = 39 },
    { prefix = "BndEvt__G_Villa_Scripting_BP_MethCookingStation2_K2Node_ActorBoundEvent_",   ing = 56, added = 60, state = 51 },
    { prefix = "BndEvt__G_Villa_Scripting_BP_MethCookingStation3_6_K2Node_ActorBoundEvent_", ing = 57, added = 61, state = 40 },
}

local function evName(lab, n, kind)
    return LEVEL .. lab.prefix .. n .. "_SBZCookingStation" .. kind .. "Delegate__DelegateSignature"
end

local HOOKS = {
    { path = "/Script/Starbreeze.SBZHUDChatWidget:OnTextCommited", cb = onTextCommited },
    { path = "/Script/Starbreeze.SBZHUDChatWidget:OnMessageReceivedFallback", cb = onFallback },
    { path = "/Script/Starbreeze.SBZHUDChatWidget:OnMessageReceived", cb = onFallback },
    { path = "/Script/Starbreeze.SBZCookingStation:Multicast_SetState", cb = onMulticastSetState },
    { path = "/Script/Starbreeze.SBZCookingStation:OnRep_CurrentState", cb = onRepState },
    { path = "/Script/Starbreeze.SBZCookingStation:OnSabotageChanged", cb = onSabotage },
    { path = "/Script/Starbreeze.SBZCookingStation:OnAckIngredientAdded", cb = onAck },
    { path = "/Script/Starbreeze.SBZCookingStation:BP_OnIngredientAdded", cb = onBPIngredientAdded },
    { path = "/Script/Starbreeze.SBZDialogManager:Multicast_PlayDialog", cb = listenNarrator },
    { path = STATION_BP .. ":BP_OnIngredientAdded", cb = onBPIngredientAdded, needs = STATION_BP },
}
for _, lab in ipairs(LABS) do
    HOOKS[#HOOKS + 1] = { path = evName(lab, lab.ing, "Ingredient"), cb = onIngredient, needs = LEVEL_CLASS }
    HOOKS[#HOOKS + 1] = { path = evName(lab, lab.added, "IngredientAdded"), cb = onAdded, needs = LEVEL_CLASS }
    HOOKS[#HOOKS + 1] = { path = evName(lab, lab.state, "State"), cb = onState, needs = LEVEL_CLASS }
end

local CHAT_BP_CLASS = "/Game/UI/Widgets/HUD/Chat/WBP_UI_HUD_Chat.WBP_UI_HUD_Chat_C"
local CHAT_HOOKS = {
    { fn = "SystemMessageReceived", capture = true },
    { fn = "VotingMessageReceived", capture = true },
    { fn = "PlayerMessageReceived", capture = true },
    { fn = "ProcessSystemMessage",  capture = true },
    { fn = "ProcessVotingMessage",  capture = true, voting = true },
    { fn = "OnChatFocusChanged", capture = true },
    { fn = "AddText" },
    { fn = "ResetTimer", capture = true, prio = 1, noscroll = true, throttle = 1.0 },
}

local function chatHookCb(h)
    local last = -99
    return function(self, p)
        if h.throttle then
            local t = now()
            if t - last < h.throttle then return end
            last = t
        end
        if h.capture and not callingWidget then
            captureWidget(try(function() return self:get() end), h.prio or 2)
        end
        if not h.noscroll then onScrollTrigger(self) end
        if h.voting then onVotingMessage(self, p) end
    end
end

local chatClassAddr = nil
local chatHooksOk = 0

local function watchChatClass()
    local cls = try(function() return StaticFindObject(CHAT_BP_CLASS) end)
    if not cls or not cls:IsValid() then return end
    local addr = addrOf(cls)
    if not addr or chatClassAddr == addr then return end
    chatClassAddr = addr
    chatHooksOk = 0
    for _, h in ipairs(CHAT_HOOKS) do
        if pcall(RegisterHook, CHAT_BP_CLASS .. ":" .. h.fn, chatHookCb(h)) then
            chatHooksOk = chatHooksOk + 1
        end
    end
end

local registered = {}
local classAddrs = {}
local attempts = {}

local function tryRegister()
    local present = {}
    for _, h in ipairs(HOOKS) do
        if h.needs and present[h.needs] == nil then
            local cls = try(function() return StaticFindObject(h.needs) end)
            local addr = (cls and cls:IsValid()) and addrOf(cls) or nil
            present[h.needs] = addr or false
            if addr and addr ~= classAddrs[h.needs] then
                if classAddrs[h.needs] ~= nil then
                    for i, h2 in ipairs(HOOKS) do
                        if h2.needs == h.needs then registered[i] = nil end
                    end
                end
                classAddrs[h.needs] = addr
                if h.needs == LEVEL_CLASS then
                    curState = nil
                    pendingReq, lastReqIdx, sabotaged = nil, nil, false
                    lastStation, ackInteractor = nil, nil
                    isHostCached = nil
                    cachedProxy = nil
                end
            end
        end
    end

    for i, h in ipairs(HOOKS) do
        if not registered[i] then
            local allowed
            if h.needs then
                allowed = present[h.needs] and true or false
            else
                attempts[i] = (attempts[i] or 0) + 1
                allowed = attempts[i] <= 5
            end
            if allowed and pcall(RegisterHook, h.path, h.cb) then
                registered[i] = true
            end
        end
    end

    watchChatClass()
end

local function levelHooksPending()
    if not classAddrs[LEVEL_CLASS] then return true end
    for i, h in ipairs(HOOKS) do
        if h.needs and not registered[i] then return true end
    end
    return false
end

local burstUntil = 0
registerBurst = function()
    if os.time() < burstUntil then return end
    burstUntil = os.time() + 12
    local delays = { 500, 2500, 6000, 11000 }
    for _, d in ipairs(delays) do
        later(d, function()
            if d == delays[1] or levelHooksPending() then tryRegister() end
        end)
    end
end

---------------------------------------------------------------------
-- Mid-heist Reload Fix & Initial Bootstrap
---------------------------------------------------------------------
local function bootstrap()
    ExecuteInGameThread(function()
        -- 1. Find active chat widget if not yet captured
        if not chatWidget or not chatWidget:IsValid() then
            for _, w in ipairs(FindAllOf("SBZHUDChatWidget") or {}) do
                if isReal(w) then captureWidget(w, 2); break end
            end
        end
        -- 2. Find active cooking station and restore current state
        if not lastStation or not lastStation:IsValid() then
            for _, st in ipairs(FindAllOf("SBZCookingStation") or {}) do
                if isReal(st) then
                    lastStation = st
                    local s = tonumber(try(function() return st.CurrentState end))
                    if s then curState = s end
                    break
                end
            end
        end
        -- 3. Cache voting proxy
        if not cachedProxy or not cachedProxy:IsValid() then
            for _, p in ipairs(FindAllOf("SBZVotingReplicatedProxy") or {}) do
                if isReal(p) then cachedProxy = p; break end
            end
        end
        -- 4. Check host status
        local ctx = validContext()
        if ctx then isHost(ctx) end
    end)
end

local function onClientRestart()
    curState = nil
    pendingReq, lastReqIdx, sabotaged = nil, nil, false
    lastStation, ackInteractor = nil, nil
    cachedProxy = nil
    cachedPS = nil
    isHostCached = nil
    hostHasMod = false
    hostNoticeAt = -99
    bluff = nil
    registerBurst()
    later(500, bootstrap)
end

tryRegister()
bootstrap()
later(500, bootstrap)

local eventTriggers = 0
local function notify(classPath)
    local ok = pcall(function()
        NotifyOnNewObject(classPath, function()
            registerBurst()
            bootstrap()
        end)
    end)
    if ok then eventTriggers = eventTriggers + 1 end
end
notify("/Script/Starbreeze.SBZCookingStation")
notify("/Script/Starbreeze.SBZHUDChatWidget")

if pcall(RegisterHook, "/Script/Engine.PlayerController:ClientRestart", onClientRestart) then
    eventTriggers = eventTriggers + 1
end

if eventTriggers == 0 then
    LoopAsync(30000, function()
        ExecuteInGameThread(tryRegister)
        return false
    end)
end

pcall(print, string.format("[Meth Helper] v%s loaded (lang=%s, broadcast=%s, shame=%s, scrollfix=%s)",
    VERSION, state.lang, tostring(state.broadcast), tostring(state.shame), tostring(state.scrollfix)))
