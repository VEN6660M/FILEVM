local setup_original = SawWeaponBase.setup
 
function SawWeaponBase:setup(...)
    setup_original(self, ...)
    self._hit_alert_size = 0  -- Полное отсутствие шума
end